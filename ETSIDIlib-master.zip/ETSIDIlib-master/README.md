http://mhernando.github.com/ETSIDIlib

Utility library for the students of UPM - ETSIDIlib
Making playing sounds, or loading png (rgba) textures and TTF fonts very simple. 
The idea is just to write : play("myfile.mp3") or print("Hello", "Couriertt.ttf",15)
It uses internally fmod, and freetype. 
A very simple examble based on glut is included, and generated binaries (VC2012) are also included.