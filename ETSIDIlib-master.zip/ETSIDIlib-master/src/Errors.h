#pragma once
//This file holds some global error functions

#include <string>

extern void fatalError(std::string errorString);